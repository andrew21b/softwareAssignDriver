package server;

public class InvalidQuestionNumber extends Exception {

}

