package server;

public class NoMatchingAssessment extends Exception {

	public NoMatchingAssessment(String reason) {
		super(reason);
	}
}

