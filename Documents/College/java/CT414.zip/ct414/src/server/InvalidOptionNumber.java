package server;

public class InvalidOptionNumber extends Exception {

}

