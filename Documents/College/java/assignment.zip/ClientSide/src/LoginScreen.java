import java.awt.*;       // Using layouts
import java.awt.event.*; // Using AWT event classes and listener interfaces
import javax.swing.*;    // Using Swing components and containers
 
// A Swing GUI application inherits the top-level container javax.swing.JFrame
public class LoginScreen extends JFrame {
   private JTextField user, pass;
   private JButton submit;
   private boolean isVerified = false;
   
   // Constructor to setup the GUI components and event handlers
   public LoginScreen() {
      // Retrieve the content-pane of the top-level container JFrame
      // All operations done on the content-pane
      Container cp = getContentPane();
      cp.setLayout(new GridLayout(3, 2, 5, 5));  // The content-pane sets its layout
 
      cp.add(new JLabel("Username: "));
      user = new JTextField(10);
      cp.add(user);
      cp.add(new JLabel("Password: "));
      pass = new JTextField(10);
      cp.add(pass);
      
      cp.add(new JLabel(" "));
      
      submit = new JButton("Submit");
      cp.add(submit);
      
      submit.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent evt) {
        	  	String userInfo = user.getText();
        	  	String passInfo = pass.getText();
  
        	  	verifyUser(userInfo, passInfo);
        	  	if(isVerified == true){
        	  		SwingUtilities.invokeLater(new Runnable() {
        	  			@Override
        	  	         public void run() {
	        	  		new getAssesment(userInfo);
        	  			}
        	  		});
	        	  		cp.setVisible(false);
	        	  		dispose();
        	  		
        	  	}
        	  
          }
       });
 
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Exit program if close-window button clicked
      setTitle("Login"); // "super" Frame sets title
      setSize(900, 300);  // "super" Frame sets initial size
      setLocationRelativeTo(null);
      setVisible(true);   // "super" Frame shows
   }
   
   public void verifyUser(String user, String pass){
	   //connect to server and verify user
	   isVerified = true;
   }
 
   // The entry main() method
   public static void main(String[] args) {
      // Run the GUI construction in the Event-Dispatching thread for thread-safety
      SwingUtilities.invokeLater(new Runnable() {
         @Override
         public void run() {
            new LoginScreen(); // Let the constructor do the job
         }
      });
   }
}